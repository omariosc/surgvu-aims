Presence-Filtered Self-Training for Instrument Detection and Template Answering with Tool Priors

SurgVU 2026 - AIMS Lab
Author: Omar Choudhry, University of Leeds

Main source: SurgVU_Report_AIMS.tex
Reference PDF: SurgVU_Report_AIMS.pdf
Bibliography: references.bib
Editable diagram: fig_method.tex
Included vector figure: fig_method.pdf

Build from this directory with a standard TeX Live or MacTeX installation:
  latexmk -pdf -interaction=nonstopmode -halt-on-error fig_method.tex
  latexmk -pdf -interaction=nonstopmode -halt-on-error SurgVU_Report_AIMS.tex

The first command rebuilds the TikZ figure. The second compiles the report,
runs BibTeX and resolves the references. The included figure PDF lets the
report compile without regenerating the diagram.

Code: https://github.com/omariosc/surgvu-aims
